% ======== run2DExample ======== 
% This script performs Gaussian Kernel Regression on a generated 
% two-dimensional dataset.
%
% Thank you to Youngmok Yun; the 2D function is from his code here:
% http://youngmok.com/gaussian-kernel-regression-with-matlab-code/

% $Author: ChrisMcCormick $    $Date: 2014/02/25 22:00:00 $    $Revision: 1.0 $

clear;
close all;
clc;

% =================================
%             Dataset
% =================================

% Define the input range x.
x = [1:100]'; 

% Create an interesting non-linear function.
%
% The first term just creates a sine wave.
% The second term pushes the function upward after x = 50.
y_orig = sin(x/10) + (x/50).^2;

% Add some random noise to the y values. 
% randn generates datapoints with a normal distribution with mean 0 and 
% variance 1. A typical output might range from -3 to 3. The parameters
% to randn specify the matrix dimensions (a column vector with 100 rows).
y = y_orig + (0.2 * randn(100, 1));

%{
% Alternatively, you can load the data from a file in order to get consistent
% results.
data = load("2dExample.csv");
x = data(:, 1);
y_orig = data(:, 2);
y = data(:, 3);
%}

% ==================================
%            Regression
% ==================================

printf("Running Gaussian Kernel Regression over noisy data...\n");
fflush(stdout);

% Define the range of input values at which to approximate the function.
xs = [1:0.5:100]';

% Create an empty vector to hold the approximate function values.
ys = zeros(size(x));

% Set the width of the Gaussian.
% Smaller values will fit the data points more tightly, while larger
% values will create a smoother result.
sigma = 50; 

% Just compute the sigma denominator once and store the result as beta.
beta = 1 / (2 * sigma^2);

% For each sample point in 'xs'...
for (i = 1:length(xs))

	% For the query point xs(i), compute the weights for every data point 
	% in 'x'.s
	w = exp(-beta * (xs(i) - x).^2);
	
	% Multiply each output value y by the corresponding weight and take the 
	% sum, then divide by the sum of the weights.
	ys(i) = sum(w .* y) / sum(w);
end

% ==================================
%         Plot Results
% ==================================

figure(1);
hold on; 

% Plot the original function as a black line.
%plot(x, y_orig, 'k-');

% Plot the noisy data as blue dots.
plot(x, y, '.');

% Plot the approximated function as a red line.
plot(xs, ys, 'r-');

%legend('Original', 'Noisy Samples', 'Approximated');
legend('Noisy Samples', 'Approximated');
axis([0 100 -1 5]);
title(strcat("Gaussian Kernel Regression, sigma = ", num2str(sigma)));


%{
	i_begin = max(i - 5, 1);
	i_end = min(i + 5, 100);
	
	% Compute the approximated value at x = i.
	
	% Use only the nearby datapoints.
    ys(i) = gaussian_kern_reg(i, x(i_begin : i_end), y(i_begin : i_end), h);
%}	




function [Centers, betas, Theta] = trainRBFN(X_train, y_train, centersPerCategory, verbose)
% TRAINRBFN Builds an RBF Network from the provided training set.
%   [Centers, betas, Theta] = trainRBFN(X_train, y_train, centersPerCategory, verbose)
%    
%   There are three main steps to the training process:
%     1. Prototype selection through k-means clustering.
%     2. Calculation of beta coefficient (which controls the width of the 
%        RBF neuron activation function) for each RBF neuron.
%     3. Training of output weights for each category using gradient descent.
%
%   Parameters
%     X_train  - The training vectors, one per row
%     y_train  - The category values for the corresponding training vector.
%                Category values should be continuous starting from 1. (e.g.,
%                1, 2, 3, ...)
%     centersPerCategory - How many RBF centers to select per category. k-Means
%                          requires that you specify 'k', the number of 
%                          clusters to look for.
%     verbose  - Whether to print out messages about the training status.
%
%   Returns
%     Centers  - The prototype vectors stored in the RBF neurons.
%     betas    - The beta coefficient for each coressponding RBF neuron.
%     Theta    - The weights for the output layer. There is one row per neuron
%                and one column per output node / category.

% $Author: ChrisMcCormick $    $Date: 2014/02/11 22:00:00 $    $Revision: 1.1 $

	% Get the number of unique categories in the dataset.
	numCats = size(unique(y_train), 1);
	
	% Ensure category values are non-zero and continuous.
	% This allows the index of the output node to equal its category (e.g.,
	% the first output node is category 1).
	if (any(y_train == 0) || any(y_train > numCats))
		error("Category values must be non-zero and continuous.");
	end
	
	% ================================================
	%       Select RBF Centers and Parameters
	% ================================================
	% Here I am selecting the cluster centers using k-Means clustering.
	% I've chosen to separate the data by category and cluster each category
	% separately, though I've read that this step is often done over the full
	% unlabeled dataset. I haven't compared the accuracy of the two approaches.
	
	if (verbose)
		printf("1. Selecting centers through k-Means.\n");
		fflush(stdout);
	end	
	
	Centers = [];
	betas = [];	
	
    % For each of the categories...
    for (c = 1 : numCats)

		if (verbose)
			printf("  Category %d centers...\n", c);
			fflush(stdout);
		end
		
		% Select the training vectors for category 'c'.
        Xc = X_train((y_train == c), :);

        % ================================
        %      Find cluster centers
        % ================================
		
        % Pick the first 'centersPerCategory' samples to use as the initial centers.
        init_Centroids = Xc(1:centersPerCategory, :);
        
        % Run k-means clustering, with at most 100 iterations.
        [Centroids_c, memberships_c] = kMeans(Xc, init_Centroids, 100);    
        
        % Remove any empty clusters.
		toRemove = [];
		
		% For each of the centroids...
        for (i = 1 : size(Centroids_c, 1))
            % If this centroid has no members, mark it for removal.
            if (sum(memberships_c == i) == 0)        
                toRemove = [toRemove; i];
            end
        end
        
		% If there were empty clusters...
        if (~isempty(toRemove))
            % Remove the centroids of the empty clusters.
            Centroids_c(toRemove, :) = [];
            
            % Reassign the memberships (index values will have changed).
            memberships_c = findClosestCentroids(Xc, Centroids_c);
        end
        
        % ================================
        %    Compute Beta Coefficients
        % ================================
        if (verbose)
			printf("  Category %d betas...\n", c);
			fflush(stdout);
		end

		% Compute betas for all the clusters.
		betas_c = computeRBFBetas(Xc, Centroids_c, memberships_c);
        
        % Add the centroids and their beta values to the network.
        Centers = [Centers; Centroids_c];
        betas = [betas; betas_c];
    end

    % ===================================
    %        Train Output Weights
    % ===================================

    % ==========================================================
    %       Compute RBF Activations Over The Training Set
    % ===========================================================
	if (verbose)
		printf("2. Calculate RBF neuron activations over full training set.\n");
		fflush(stdout);
	end

    % First, compute the RBF neuron activations for all training examples.

    % The X_activ matrix stores the RBF neuron activation values for each training 
    % example: one row per training example and one column per RBF neuron.
    X_activ = zeros(rows(X_train), rows(Centers));

    % For each training example...
    for (i = 1 : rows(X_train))
       
        input = X_train(i, :);
       
       % Get the activation for all RBF neurons for this input.
        z = getRBFActivations(Centers, betas, input);
       
        % Store the activation values 'z' for training example 'i'.
        X_activ(i, :) = z';
    end

    % Add a column of 1s for the bias term.
    X_activ = [ones(rows(X_train), 1), X_activ];

    % =============================================
    %        Perform Gradient Descent
    % =============================================

	if (verbose)
		printf("3. Learn output weights.\n");
		fflush(stdout);
	end

    % Don't perform any regularization (lambda = 0).
    lambda = 1;

    % Perform 200 iterations of gradient descent.
    maxIter = 200;

    % Initialize theta to 0 for all RBF neurons. Add another zero to theta for 
	% the bias term.
    initial_theta = zeros(rows(Centers) + 1, 1);

    % Set the options for fminunc.
    options = optimset('GradObj', 'on', 'MaxIter', maxIter);

    % Create a matrix to hold all of the output weights.
    % There is one column per category / output neuron.
    Theta = zeros(rows(Centers) + 1, numCats);

    % For each category...
    for (c = 1 : numCats)

        % Make the y values binary--1 for category 'c' and 0 for all other categories.
        y_c = (y_train == c);

        % Run the optimization routine.
        [Theta(:, c), J, exit_flag] = ...
            fminunc(@(t)(costFunctionRBFN(t, X_activ, y_c, lambda)), initial_theta, options);
			
		%  ================================
		%      Manual Gradient Descent
		%  ================================
		%  You can alternatively use the below code to run gradient descent manually,
		%  and plot the cost over each iteration.
		%
		%  % Set the learning rate
		%  alpha = 1;
		%  J_history = zeros(maxIter, 1);
		%  
		%  for (i = 1 : maxIter)
		%      % Compute the cost and gradients.    
		%      [J, grad] = costFunctionRBFN(initial_theta, X_activ, y_c, lambda);
		%      
		%      % Record the cost for this iteration.
		%      J_history(i) = J;
		%     
		%      % Simultaneously update all values of theta.
		%      Theta(:, c) -= grad * alpha;
		%  end
		%  
		%  % Plot the cost
		%  figure(c);
		%  hold off;
		%  plot(J_history);
		%  title('Cost At Each Iteration');

    end
	
end


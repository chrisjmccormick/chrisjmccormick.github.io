% ======== runRBFNExample ========
% This script trains an RBF Network on an example dataset, and plots the
% resulting score function and decision boundary.
% 
% There are three main steps to the training process:
%   1. Prototype selection through k-means clustering.
%   2. Calculation of beta coefficient (which controls the width of the 
%      RBF neuron activation function) for each RBF neuron.
%   3. Training of output weights for each category using gradient descent.
%
% Once the RBFN has been trained this script performs the following:
%   1. Generates a contour plot showing the output of the category 1 output
%      node.
%   2. Shows the original dataset with the placements of the protoypes and
%      an approximation of the decision boundary between the two classes.
%   3. Evaluates the RBFN's accuracy on the training set.

% $Author: ChrisMcCormick $    $Date: 2013/08/15 22:00:00 $    $Revision: 1.0 $

% Clear all existing variables from the workspace.
clear;

% Remove any holds on the existing plots.
figure(1);
hold off;

figure(2);
hold off;

% Add the subdirectories to the path.
addpath('kMeans');
addpath('RBFN');

% Load the data set. 
% This loads two variables, X and y.
%   X - The dataset, 1 sample per row.
%   y - The corresponding label (category 1 or 2).
% The data is randomly sorted and grouped by category.
load 'dataset.mat'

% ================================
%      Find cluster centers
% ================================

disp("Selecting prototypes through k-means...\n");

% Separate the samples by category.
X1 = X((y == 1), :);
X2 = X((y == 2), :);

% Pick 10 random examples from each category as initial centroids. Since we've
% already randomized the data set, the first 10 samples are sufficient.
init_centroids1 = X1(1:10, :);
init_centroids2 = X2(1:10, :);

% Run k-means clustering (for 100 iterations) on both classes.
[centroids1, memberships1] = kMeans(X1, init_centroids1, 100);
[centroids2, memberships2] = kMeans(X2, init_centroids2, 100);

% Use the cluster centers as the RBF neuron prototypes.
centers = [centroids1; centroids2];

% ================================
%    Compute Beta Coefficients
% ================================

printf("Calculating beta coefficients...\n");
fflush(stdout);

% Compute the beta values for every RBF neuron.
betas1 = computeRBFBetas(X1, centroids1, memberships1);
betas2 = computeRBFBetas(X2, centroids2, memberships2);

betas = [betas1; betas2];

% ===================================
%        Train Output Weights
% ===================================

% ==========================================================
%       Compute RBF Activations Over The Training Set
% ===========================================================

% First, compute the RBF neuron activations for all training examples.
disp("Calculating RBF neuron responses to training inputs...\n");

% The X_train matrix becomes a matrix with one row per training example and one
% column per RBF neuron.
X_train = zeros(rows(X), rows(centers));

% For each training example...
for (i = 1 : rows(X))
   
    input = X(i, :);
   
   % Get the activation for all RBF neurons for this input.
    z = getRBFActivations(centers, betas, input);
   
    X_train(i, :) = z';
end

% Add a column of 1s for the bias term.
X_train = [ones(rows(X), 1), X_train];

% =============================================
%        Perform Gradient Descent
% =============================================

disp("Training output weights...\n");

% Don't perform any regularization (lambda = 0).
lambda = 0;

% Perform 200 iterations of gradient descent.
maxIter = 200;

% Initialize theta to 0 for all RBF neurons + 1 for the bias term.
initial_theta = zeros(rows(centers) + 1, 1);

% Set the options for fminunc.
options = optimset('GradObj', 'on', 'MaxIter', maxIter);

% Learn category 1 weights.
y_train = (y == 1);

% Run the optimization routine.
[weights1, J, exit_flag] = ...
	fminunc(@(t)(costFunctionRBFN(t, X_train, y_train, lambda)), initial_theta, options);

% Learn category 2 weights.    
y_train = (y == 2);

% Run the optimization routine.
[weights2, J, exit_flag] = ...
	fminunc(@(t)(costFunctionRBFN(t, X_train, y_train, lambda)), initial_theta, options);

%  ================================
%      Manual Gradient Descent
%  ================================
%  You can alternatively use the below code to run gradient descent manually,
%  and plot the cost over each iteration.
%
%  % Set the learning rate
%  alpha = 1;
%  J_history = zeros(maxIter, 1);
%  
%  for (i = 1 : maxIter)
%      % Compute the cost and gradients.    
%      [J, grad] = costFunctionRBFN(weights1, X_train, y_train, lambda);
%      
%      % Record the cost for this iteration.
%      J_history(i) = J;
%     
%      % Simultaneously update all values of theta.
%      theta -= grad * alpha;
%  end
%  
%  % Plot the cost
%  hold off;
%  plot(J_history);
%  title('Cost At Each Iteration');
   
% ================================
%         Contour Plots
% ================================

printf("Evaluating RBFN over input space...\n");
fflush(stdout);

% Define a grid over which to evaluate the RBFN.
gridSize = 100;
u = linspace(-2, 2, gridSize);
v = linspace(-2, 2, gridSize);

% We'll store the scores for each category as well as the 'prediction' for
% each point on the grid.
scores1 = zeros(length(u), length(v));
scores2 = zeros(length(u), length(v));
p = zeros(length(u), length(v));

% Evaluate the RBFN over the grid.
% For each row of the grid...
for (i = 1 : length(u))
    
    % Report our progress every 10th row.
    if (mod(i, 10) == 0)
        printf("  Grid row = %d / %d...\n", i, gridSize);
        fflush(stdout);
    end
    
    % For each column of the grid...
    for (j = 1 : length(v))
        
        % Compute the category 1 and 2 scores.
        scores1(i, j) = evaluateRBFN(centers, betas, weights1, [u(i), v(j)]);
        scores2(i, j) = evaluateRBFN(centers, betas, weights2, [u(i), v(j)]);
        
        % Pick the higher score.
        if (scores1(i, j) == scores2(i, j))
            p(i,j) = 1.5;
        elseif (scores1(i, j) > scores2(i, j))
            p(i, j) = 1;
        else 
            p(i, j) = 2;
        end
    end
end

% Contour Plot #1: Plot the category 1 score.
% Plot the contour lines to show the continuous-valued function which is the
% output of the category 2 node RBFN.
figure(1);
[C, h] = contour(u, v, scores1');
%set(h,'ShowText','on','TextStep',get(h,'LevelStep')*2);
hold on;
axis([-2 2 -2 2]);
plot(centers(:, 1), centers(:, 2), 'k*');
title('Category 1 Output');

printf("Minimum category 1 score: %.2f\n", min(min(scores1)));
printf("Maximum category 1 score: %.2f\n", max(max(scores1)));

% Contour Plot #2: Plot the approximate decision boundary over the dataset.
figure(2);
% Plot the data set and neuron prototypes.
plot(X(y == 1, 1), X(y == 1, 2), 'ro');
hold on;
axis([-2 2 -2 2]);
plot(X(y == 2, 1), X(y == 2, 2), 'bx');
plot(centers(:, 1), centers(:, 2), 'k*');

% Draw a contour plot line where p = 1.5. The contour function performs
% some interpolation of the points for you.
[c, h] = contour(u, v, p', [1.5, 1.5]);
title('Decision Boundary');

% ========================================
%       Measure Training Accuracy
% ========================================

disp("Measuring training accuracy...");

numRight = 0;

wrong = [];

% For each training sample...
for (i = 1 : rows(X))
    % Compute the scores for both categories.
    score1 = evaluateRBFN(centers, betas, weights1, X(i, :));
    score2 = evaluateRBFN(centers, betas, weights2, X(i, :));
    
    % Validate the result.
    if (((score2 >= score1) && (y(i) == 2)) ||
        ((score2 < score1) && (y(i) == 1)))
        numRight++;
    else
        wrong = [wrong; X(i, :)];
    end
    
end

% Mark the incorrectly recognized samples with a black asterisk.
%plot(wrong(:, 1), wrong(:, 2), 'k*');

accuracy = numRight / rows(X) * 100;
printf("Training accuracy: %d / %d, %.1f%%\n", numRight, rows(X), accuracy);

function z = evaluateRBFN(centers, betas, weights, input)
% EVALUATERBFN Computes the outputs of an RBF Network for the provided input.
%   z = evaluateRBFN(centers, betas, weights, input) Evaluates the RBFN over
%   given input using the provided output weights.
%
%   This function computes the output value for a single output node whose
%   weights are given by the 'weights' parameter. 
%
%   Parameters
%     centers  - The prototype vectors for the RBF neurons.
%     betas    - The beta coefficients for the corresponding prototypes.
%     weights  - The output weights to apply to the neuron activations.
%     input    - The input vector to evaluate the RBFN over.
%
%   Returns
%     A single value representing the networks output value for the output node
%     given by the 'weights' parameter.
    
% $Author: ChrisMcCormick $    $Date: 2013/08/15 22:00:00 $    $Revision: 1.0 $
    
    % Compute the activations for each RBF neuron for this input.
    phis = getRBFActivations(centers, betas, input);
    
    % Add a 1 to the beginning of the activations vector for the bias term.
    phis = [1; phis];
    
    % Multiply the activations by the weights and take the sum.
    z = weights' * phis;
        
end